import { useMemo, useState } from 'react';
import { NavLink, Navigate, Route, Routes, useLocation, useNavigate } from 'react-router-dom';

const DEMO_USERS = {
  admin: {
    username: 'admin',
    password: 'admin123',
    role: 'Admin',
    name: 'Ava Admin',
  },
  editor: {
    username: 'editor',
    password: 'editor123',
    role: 'Editor',
    name: 'Ethan Editor',
  },
  viewer: {
    username: 'viewer',
    password: 'viewer123',
    role: 'Viewer',
    name: 'Vera Viewer',
  },
};

function createMockJwt(user) {
  const payload = {
    sub: user.username,
    role: user.role,
    name: user.name,
    exp: Math.floor(Date.now() / 1000) + 60 * 60,
  };

  return `header.${btoa(JSON.stringify(payload))}.signature`;
}

function decodeJwt(token) {
  try {
    const [, payloadBase64] = token.split('.');
    return JSON.parse(atob(payloadBase64));
  } catch {
    return null;
  }
}

function getStoredUser() {
  const token = localStorage.getItem('jwt-demo-token');
  if (!token) return null;
  const payload = decodeJwt(token);
  if (!payload) return null;
  return {
    token,
    username: payload.sub,
    role: payload.role,
    name: payload.name,
  };
}

function ProtectedRoute({ children, allowedRoles }) {
  const location = useLocation();
  const storedUser = getStoredUser();

  if (!storedUser) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  if (allowedRoles && !allowedRoles.includes(storedUser.role)) {
    return <Navigate to="/unauthorized" replace />;
  }

  return children;
}

function LoginPage({ onLogin }) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();
  const location = useLocation();
  const from = location.state?.from?.pathname || '/dashboard';

  const handleSubmit = (event) => {
    event.preventDefault();
    const user = DEMO_USERS[username.toLowerCase()];

    if (!user || user.password !== password) {
      setError('Invalid credentials. Try admin/admin123, editor/editor123, or viewer/viewer123.');
      return;
    }

    const token = createMockJwt(user);
    localStorage.setItem('jwt-demo-token', token);
    onLogin({
      token,
      username: user.username,
      role: user.role,
      name: user.name,
    });
    navigate(from, { replace: true });
  };

  return (
    <div className="form-card card">
      <h1>Secure Login</h1>
      <p className="helper">This demo uses a mock JWT stored in localStorage to simulate stateless authentication.</p>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="username">Username</label>
          <input id="username" value={username} onChange={(e) => setUsername(e.target.value)} placeholder="admin" />
        </div>
        <div className="form-group">
          <label htmlFor="password">Password</label>
          <input id="password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="admin123" />
        </div>
        <button type="submit" className="primary">Login</button>
        {error ? <p className="error">{error}</p> : null}
      </form>
    </div>
  );
}

function HomePage({ user, onLogout }) {
  return (
    <div className="card">
      <h1>Authentication & RBAC Demo</h1>
      <p className="helper">This app shows JWT-based login, token storage, and protected routes based on user roles.</p>
      <div className="grid">
        <div className="card">
          <h3>Current user</h3>
          <p><strong>{user?.name}</strong></p>
          <span className="badge">{user?.role}</span>
        </div>
        <div className="card">
          <h3>Stored token</h3>
          <p className="helper">The mock JWT is saved in localStorage and attached to the session state.</p>
          <p>{user?.token?.slice(0, 24)}...</p>
        </div>
      </div>
      <div style={{ marginTop: 20 }}>
        <button className="primary" onClick={onLogout}>Logout</button>
      </div>
    </div>
  );
}

function DashboardPage({ user }) {
  return (
    <div className="card">
      <h2>Dashboard</h2>
      <p className="helper">This route is available to authenticated users.</p>
      <div className="grid">
        <div className="card">
          <h3>Role-based access</h3>
          <p>Welcome, {user?.name}. Your role is {user?.role}.</p>
        </div>
        <div className="card">
          <h3>Permissions</h3>
          <p>{user?.role === 'Admin' ? 'Manage users, settings, and reports.' : user?.role === 'Editor' ? 'Create and edit content.' : 'View reports and read-only content.'}</p>
        </div>
      </div>
    </div>
  );
}

function AdminPage() {
  return (
    <div className="card">
      <h2>Admin Panel</h2>
      <p className="helper">Only users with the Admin role can reach this page.</p>
    </div>
  );
}

function EditorPage() {
  return (
    <div className="card">
      <h2>Editor Workspace</h2>
      <p className="helper">Editors can manage content here.</p>
    </div>
  );
}

function UnauthorizedPage() {
  return (
    <div className="card">
      <h2>Access Denied</h2>
      <p className="helper">You do not have permission to view this page.</p>
    </div>
  );
}

function App() {
  const [user, setUser] = useState(() => getStoredUser());
  const navigate = useNavigate();

  const logout = () => {
    localStorage.removeItem('jwt-demo-token');
    setUser(null);
    navigate('/login');
  };

  const currentUser = useMemo(() => user, [user]);

  return (
    <div className="app-shell">
      <header className="topbar">
        <h2 style={{ margin: 0 }}>JWT Auth + RBAC</h2>
        <nav className="nav-links">
          {currentUser ? (
            <>
              <NavLink to="/" end>Home</NavLink>
              <NavLink to="/dashboard">Dashboard</NavLink>
              {currentUser.role === 'Admin' ? <NavLink to="/admin">Admin</NavLink> : null}
              {currentUser.role === 'Admin' || currentUser.role === 'Editor' ? <NavLink to="/editor">Editor</NavLink> : null}
              <button onClick={logout}>Logout</button>
            </>
          ) : (
            <NavLink to="/login">Login</NavLink>
          )}
        </nav>
      </header>

      <Routes>
        <Route path="/login" element={<LoginPage onLogin={setUser} />} />
        <Route path="/" element={<ProtectedRoute><HomePage user={currentUser} onLogout={logout} /></ProtectedRoute>} />
        <Route path="/dashboard" element={<ProtectedRoute><DashboardPage user={currentUser} /></ProtectedRoute>} />
        <Route path="/admin" element={<ProtectedRoute allowedRoles={['Admin']}><AdminPage /></ProtectedRoute>} />
        <Route path="/editor" element={<ProtectedRoute allowedRoles={['Admin', 'Editor']}><EditorPage /></ProtectedRoute>} />
        <Route path="/unauthorized" element={<UnauthorizedPage />} />
        <Route path="*" element={<Navigate to={currentUser ? '/dashboard' : '/login'} replace />} />
      </Routes>
    </div>
  );
}

export default App;
